import random

# List of random agent names
agent_names = ["Fah", "Ray", "Maya", "Victorious", "Satvik", "Zoya", "Pheem", "Ridhvik"]

# List of important words and their responses
important_responses = {
    "movies": "How about watching the suspense horror movie The Game Over.",
    "tea": "Let's go to the opening of a new tea shop near my home.",
    "job": "Did you get the job?",
    "hospital": "I heard that hospital is renowned for its psychiatry department.",
    "family": "A family gathering is happening this Friday."
}

# List of general responses
general_responses = [
    "Sure, it will be fun.",
    "Ok then, let us meet today.",
    "Yes, I got that job.",
    "Then I will take an appointment soon.",
    "That is great as I will be attending after a long time."
]

def chatbot():
    user_name = input("Please enter your name: ")
    agent_name = random.choice(agent_names)
    print(f"Hello {user_name}! Welcome from the University of Poppleton! My name is {agent_name}. How may I guide you today?")
    
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["bye", "quit", "exit"]:
            print(f"Goodbye {user_name}! Have an amazing day!")
            break
        
        # Check for important words
        found_keyword = False
        for key, response in important_responses.items():
            if key in user_input.lower():
                print(f"{agent_name}: {response}")
                found_keyword = True
                break
        
        if not found_keyword:
            # If no important word is found, give a random response
            response = random.choice(general_responses)
            print(f"{agent_name}: {response}")
    
if __name__ == "__main__":
    chatbot()